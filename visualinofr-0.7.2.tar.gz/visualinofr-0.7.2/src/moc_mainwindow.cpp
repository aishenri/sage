/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[41];
    char stringdata0[592];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 11), // "actionAbout"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 19), // "actionCloseMessages"
QT_MOC_LITERAL(4, 44, 10), // "actionCode"
QT_MOC_LITERAL(5, 55, 14), // "actionExamples"
QT_MOC_LITERAL(6, 70, 18), // "actionExportSketch"
QT_MOC_LITERAL(7, 89, 16), // "actionIconLabels"
QT_MOC_LITERAL(8, 106, 13), // "actionInclude"
QT_MOC_LITERAL(9, 120, 21), // "actionInjectWebHelper"
QT_MOC_LITERAL(10, 142, 20), // "actionInsertLanguage"
QT_MOC_LITERAL(11, 163, 14), // "actionMessages"
QT_MOC_LITERAL(12, 178, 13), // "actionMonitor"
QT_MOC_LITERAL(13, 192, 17), // "actionMonitorSend"
QT_MOC_LITERAL(14, 210, 9), // "actionNew"
QT_MOC_LITERAL(15, 220, 10), // "actionOpen"
QT_MOC_LITERAL(16, 231, 18), // "actionOpenMessages"
QT_MOC_LITERAL(17, 250, 11), // "actionGraph"
QT_MOC_LITERAL(18, 262, 10), // "actionQuit"
QT_MOC_LITERAL(19, 273, 18), // "actionDocumentRedo"
QT_MOC_LITERAL(20, 292, 18), // "actionDocumentUndo"
QT_MOC_LITERAL(21, 311, 12), // "actionUpload"
QT_MOC_LITERAL(22, 324, 12), // "actionVerify"
QT_MOC_LITERAL(23, 337, 10), // "actionSave"
QT_MOC_LITERAL(24, 348, 12), // "actionSaveAs"
QT_MOC_LITERAL(25, 361, 14), // "actionSettings"
QT_MOC_LITERAL(26, 376, 12), // "actionZoomIn"
QT_MOC_LITERAL(27, 389, 13), // "actionZoomOut"
QT_MOC_LITERAL(28, 403, 14), // "onBoardChanged"
QT_MOC_LITERAL(29, 418, 14), // "onLoadFinished"
QT_MOC_LITERAL(30, 433, 8), // "finished"
QT_MOC_LITERAL(31, 442, 17), // "onProcessFinished"
QT_MOC_LITERAL(32, 460, 8), // "exitCode"
QT_MOC_LITERAL(33, 469, 22), // "onProcessOutputUpdated"
QT_MOC_LITERAL(34, 492, 16), // "onProcessStarted"
QT_MOC_LITERAL(35, 509, 15), // "onSourceChanged"
QT_MOC_LITERAL(36, 525, 22), // "onStatusMessageChanged"
QT_MOC_LITERAL(37, 548, 7), // "message"
QT_MOC_LITERAL(38, 556, 10), // "readSerial"
QT_MOC_LITERAL(39, 567, 6), // "unhide"
QT_MOC_LITERAL(40, 574, 17) // "updateSerialPorts"

    },
    "MainWindow\0actionAbout\0\0actionCloseMessages\0"
    "actionCode\0actionExamples\0actionExportSketch\0"
    "actionIconLabels\0actionInclude\0"
    "actionInjectWebHelper\0actionInsertLanguage\0"
    "actionMessages\0actionMonitor\0"
    "actionMonitorSend\0actionNew\0actionOpen\0"
    "actionOpenMessages\0actionGraph\0"
    "actionQuit\0actionDocumentRedo\0"
    "actionDocumentUndo\0actionUpload\0"
    "actionVerify\0actionSave\0actionSaveAs\0"
    "actionSettings\0actionZoomIn\0actionZoomOut\0"
    "onBoardChanged\0onLoadFinished\0finished\0"
    "onProcessFinished\0exitCode\0"
    "onProcessOutputUpdated\0onProcessStarted\0"
    "onSourceChanged\0onStatusMessageChanged\0"
    "message\0readSerial\0unhide\0updateSerialPorts"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      36,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  194,    2, 0x0a /* Public */,
       3,    0,  195,    2, 0x0a /* Public */,
       4,    0,  196,    2, 0x0a /* Public */,
       5,    0,  197,    2, 0x0a /* Public */,
       6,    0,  198,    2, 0x0a /* Public */,
       7,    0,  199,    2, 0x0a /* Public */,
       8,    0,  200,    2, 0x0a /* Public */,
       9,    0,  201,    2, 0x0a /* Public */,
      10,    0,  202,    2, 0x0a /* Public */,
      11,    0,  203,    2, 0x0a /* Public */,
      12,    0,  204,    2, 0x0a /* Public */,
      13,    0,  205,    2, 0x0a /* Public */,
      14,    0,  206,    2, 0x0a /* Public */,
      15,    0,  207,    2, 0x0a /* Public */,
      16,    0,  208,    2, 0x0a /* Public */,
      17,    0,  209,    2, 0x0a /* Public */,
      18,    0,  210,    2, 0x0a /* Public */,
      19,    0,  211,    2, 0x0a /* Public */,
      20,    0,  212,    2, 0x0a /* Public */,
      21,    0,  213,    2, 0x0a /* Public */,
      22,    0,  214,    2, 0x0a /* Public */,
      23,    0,  215,    2, 0x0a /* Public */,
      24,    0,  216,    2, 0x0a /* Public */,
      25,    0,  217,    2, 0x0a /* Public */,
      26,    0,  218,    2, 0x0a /* Public */,
      27,    0,  219,    2, 0x0a /* Public */,
      28,    0,  220,    2, 0x0a /* Public */,
      29,    1,  221,    2, 0x0a /* Public */,
      31,    1,  224,    2, 0x0a /* Public */,
      33,    0,  227,    2, 0x0a /* Public */,
      34,    0,  228,    2, 0x0a /* Public */,
      35,    0,  229,    2, 0x0a /* Public */,
      36,    1,  230,    2, 0x0a /* Public */,
      38,    0,  233,    2, 0x0a /* Public */,
      39,    0,  234,    2, 0x0a /* Public */,
      40,    0,  235,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   30,
    QMetaType::Void, QMetaType::Int,   32,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   37,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->actionAbout(); break;
        case 1: _t->actionCloseMessages(); break;
        case 2: _t->actionCode(); break;
        case 3: _t->actionExamples(); break;
        case 4: _t->actionExportSketch(); break;
        case 5: _t->actionIconLabels(); break;
        case 6: _t->actionInclude(); break;
        case 7: _t->actionInjectWebHelper(); break;
        case 8: _t->actionInsertLanguage(); break;
        case 9: _t->actionMessages(); break;
        case 10: _t->actionMonitor(); break;
        case 11: _t->actionMonitorSend(); break;
        case 12: _t->actionNew(); break;
        case 13: _t->actionOpen(); break;
        case 14: _t->actionOpenMessages(); break;
        case 15: _t->actionGraph(); break;
        case 16: _t->actionQuit(); break;
        case 17: _t->actionDocumentRedo(); break;
        case 18: _t->actionDocumentUndo(); break;
        case 19: _t->actionUpload(); break;
        case 20: _t->actionVerify(); break;
        case 21: _t->actionSave(); break;
        case 22: _t->actionSaveAs(); break;
        case 23: _t->actionSettings(); break;
        case 24: _t->actionZoomIn(); break;
        case 25: _t->actionZoomOut(); break;
        case 26: _t->onBoardChanged(); break;
        case 27: _t->onLoadFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 28: _t->onProcessFinished((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->onProcessOutputUpdated(); break;
        case 30: _t->onProcessStarted(); break;
        case 31: _t->onSourceChanged(); break;
        case 32: _t->onStatusMessageChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 33: _t->readSerial(); break;
        case 34: _t->unhide(); break;
        case 35: _t->updateSerialPorts(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 36)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 36;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 36)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 36;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
